


ReadMe Carolyn

Here is some explanation on how some of this stuff works.


# Navigation #

The Navigation on the right side of a desktop view.(Not visible on mobile devices)

If you change any of the heading of any of the sections the navigation will automatically change to the new heading. 


# Content #

I am using HTML Character Code for adding in character symbols.( like single quotes, and double quotes, etc )

Here are some that might be helpful. 
http://designerstoolbox.com/designresources/html/


# Contact #

### Email Change ##
In the content/script folder, open the index.php file.
On Line 15 you can replace the e-mail address in there to where you would like the contact form to send the information. 
As of right now it is set to  contactus@pixelingo.com


### Thank You Change ###
In the content/thanks folder, open the index.php file.
After someone fills out the form properly they will be sent to this thank you page.
Feel fee to change the content to say anything you would like in here. 


### Error Change ###
In the content/?error folder, open the index.php file.
If someone fails to fill out the contact form properly. (Such as a bad e-mail address)
This page looks the same as the home page EXCEPT at the very beginning of the contact form shows an error message. 

 
    
# Launch #


Everything is in this Pixelingo.zip file and can just be extracted and uploaded to your hosting provider.
If you would like, I could launch this. I would just need to know some server information.
But i would still like for you to go over all the content and see if is anything else that you would like to add or remove.





